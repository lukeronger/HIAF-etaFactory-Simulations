pylhef
======

Les Houches Events Format parser
