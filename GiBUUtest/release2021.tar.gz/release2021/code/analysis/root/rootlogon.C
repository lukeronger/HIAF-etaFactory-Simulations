{
  gStyle->SetOptStat(000000000);
//  gStyle->SetLineWidth(2.);
  gStyle->SetTextSize(0.05);
//  gStyle->SetLabelSize(0.06,"xy");
  gStyle->SetTitleSize(0.05,"XY");
  gStyle->SetTitleOffset(1.4,"Y");
  gStyle->SetTitleOffset(1.0,"X");
//  gStyle->SetPadTopMargin(0.1);
  gStyle->SetPadRightMargin(0.05);
//  gStyle->SetPadBottomMargin(0.16);
  gStyle->SetPadLeftMargin(0.15);
  gStyle->SetCanvasColor(kWhite);
}

